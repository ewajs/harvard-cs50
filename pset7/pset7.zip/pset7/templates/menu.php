<div class="form-group">
<ul class="nav nav-tabs nav-justified">
  <li role="presentation"><a href="index.php">Portfolio</a></li>
  <li role="presentation"><a href="quote.php">Quote</a></li>
  <li role="presentation"><a href="buy.php">Buy</a></li>
  <li role="presentation"><a href="sell.php">Sell</a></li>
  <li role="presentation"><a href="history.php">History</a></li>
  <li role="presentation"><a href="logout.php"><strong>Log Out</strong></a></li>
</ul>
</div>
