<?php
	print("The price of <strong> $name ($symbol) </strong> is <strong>$" . number_format($price,4) . " </strong> per share. <a href='quote.php'>Check another company</a> or go to <a href='index'>portfolio</a>.");
?>
